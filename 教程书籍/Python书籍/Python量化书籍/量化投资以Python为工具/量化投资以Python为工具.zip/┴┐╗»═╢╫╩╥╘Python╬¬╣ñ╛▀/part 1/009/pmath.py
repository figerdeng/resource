# -*- coding: utf-8 -*-

def findMax(sequence):
    maxValue = sequence(0)
    
    for a in sequence:
        if a > sequence:
            maxValue = a
            
    return(maxValue)
    
    
def findMin(sequence):
    minValue = sequence(0)
    
    for a in sequence:
        if a < sequence:
            minValue = a
            
    return(minValue)