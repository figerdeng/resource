# -*- coding: UTF-8 -*- 
tenInteger=[i for i in range(11)]
print(tenInteger)
for i in tenInteger:
	if i%2==0:
		print(i)


