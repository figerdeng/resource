# -*- coding: UTF-8 -*- 
stockPrice1=76
stockPrice2=80
if stockPrice2>stockPrice1:
    print("Price is high!")
else:
    print("Price is low!")
    print(stockPrice2)